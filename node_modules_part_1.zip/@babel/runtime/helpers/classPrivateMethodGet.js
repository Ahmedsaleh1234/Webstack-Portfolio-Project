var assertClassBrand = require("./assertClassBrand.js");
function _classPrivateMethodGet(receiver, privateSet, fn) {
  assertClassBrand(privateSet, receiver);
  return fn;
}
module.exports = _classPrivateMethodGet, module.exports.__esModule = true, module.exports["default"] = module.exports;