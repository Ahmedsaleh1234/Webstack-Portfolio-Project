module.exports = require('./dist/js.cookie')
