throw new Error(
  "This module cannot be imported from a Server Component module. " +
    "It should only be used from a Client Component."
);
