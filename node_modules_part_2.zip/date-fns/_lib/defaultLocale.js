"use strict";
Object.defineProperty(exports, "defaultLocale", {
  enumerable: true,
  get: function () {
    return _index.enUS;
  },
});
var _index = require("../locale/en-US.js");
