export declare function assertType<T>(_: T): void;
export declare function resetDefaultOptions(): void;
export declare function generateOffset(originalDate: Date): string;
