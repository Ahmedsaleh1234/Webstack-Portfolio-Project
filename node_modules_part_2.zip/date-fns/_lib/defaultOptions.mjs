let defaultOptions = {};

export function getDefaultOptions() {
  return defaultOptions;
}

export function setDefaultOptions(newOptions) {
  defaultOptions = newOptions;
}
