import type { RoundingMethod } from "../types.js";
export declare function getRoundingMethod(
  method: RoundingMethod | undefined,
): (number: number) => number;
