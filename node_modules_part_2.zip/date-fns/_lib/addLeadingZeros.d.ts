export declare function addLeadingZeros(
  number: number,
  targetLength: number,
): string;
